function h1(text) {
  text=prompt();
  document.write('<h1>' +text+ '</h1>');
}
h1();
